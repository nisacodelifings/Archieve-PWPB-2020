package com.example.intentparcelable;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class MoveActivity extends AppCompatActivity {

    @Override
    protected  void onCreate(Bundle savedInstanveState){
        super.onCreate(savedInstanveState);
        setContentView(R.layout.activity_move);
    }
}
